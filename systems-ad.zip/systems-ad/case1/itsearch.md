###### Bain & Company
 is an American global management consulting firm headquartered in Boston, Massachusetts. It provides advisory services to businesses, nonprofit organizations, and governments, and is one of the Big Three strategy consulting firms (MBB). The CEO is Bob Bechek and the CFO is Len Banos. Bain has 54 offices in 34 countries and 5,700 employees

http://www.bain.com/consulting-services/information-technology/index.aspx

###### IT Consulting New York
Major clients in various fields including real estate, gas & oil, creative agencies & marketers, and security services.

http://www.itconsultingnewyork.com

###### Alcalá Consulting
ALCALA delivers a wide selection of business and technology solutions to help its clients achieve higher business performance. ALCALA’s core portfolio comprises business applications and information technology services. 

https://www.alcalaconsulting.com

###### Dell
Formerly known as Perot Systems, Dell's IT services division is a major provider of technology consulting to hospitals and government departments. Founded in 1988 by former U.S. presidential candidate Ross Perot, it was acquired by Dell in 2009 for $3.9 billion. Dell Services has been acquired by NTT DATA, a top 10 global IT services company for over $3 billion.

http://www.dell.com/en-us/work/learn/by-service-type-it-consulting