Carlos Vigil  
Prof. S. Walker  
Systems A&D  
February 15th, 2017

# SCR TIMS: Interviews

## Goals
The main purpose of the interview is to map out where each group will fit into this project and how well they know their responsibilities or their projected vision of TIMS.

## Interviewees

### Project Management

- Shelly Grant

### Business Solutions

- Joyce Donahue
- Roy Brown

### Network/Web

- Lyle Newhart

## Questions

1. How excited are you for the upcoming TIMS project?
2. How would you describe the Training Group to prospective clients?
2. How will the project directly effect you?
3. On a scale of 1-10 how well do you know the business implications of starting and maintaining this project?
4. What immediate issues do you see arising from TIMS?
5. How would you like the rest of the SCR groups to interact with you and participate in helping you achieve your goals for this project?
5. Is there anything else I should have asked about concerning the new Training Group?