Carlos Vigil  
Prof. S. Walker  
Systems A&D  
February 15th, 2017

# SCR TIMS: Understanding the Opportunity
SCR continues to innovate at the pace of tech, lightning fast!

Now under development, our Training Group will extend the SCR motto “We Know IT!” to the public and our clients. Using in-house developed learning management system TIMS, the training group will develop, maintain, and teach learning curriculums for various technical courses. Our initial offering will include courses for Windows Office applications, GroupWise, SQL, Visual Basic, Visual C++, Java, and the Microsoft .NET development environment. And, we will later have courses for certification prep in A+, MCSE, MCSD, MOUS, NetWare, and GroupWise.

We’re proud to share IT knowledge and put the power of tech in your hands.