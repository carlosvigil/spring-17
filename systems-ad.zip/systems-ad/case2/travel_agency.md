Carlos Vigil  
Prof. S. Walker  
Systems A&D  
February 15th, 2017

# Project 2: Travel Agency
> Suppose you own a travel agency in a large city. You have many corporate clients, but growth has slowed somewhat. Some long-term employees are getting discouraged, but you feel that there might be a way to make technology work in your favor. Use your imagination and suggest at least one strength, weakness, opportunity, and threat that your business faces.

S: The agency strength comes from the many corporate clients which carry large volume sales. This network is extremely valuable as it reaches and affects many individuals.

W: The corporate nature of our clients is also a weak point for growth as the individuals don’t directly interact with us or see the value outside of their company activities.

O: Using current technologies and social changes we can reach more people and at their level. Social media will be the greatest asset in expanding our client base.

T: As a respected agency in the corporate world the biggest threat are the changes in public perception, therefore, maintaining our current clients’ trust will be critical.
