# Backers

Support Framework7 development by [pledging on Patreon](https://www.patreon.com/vladimirkharlampidi)!

### $1000

[Currently vacant. It could be you!](https://www.patreon.com/bePatron?patAmt=1000.0&exp=1&u=4109762&rid=830901)

---

### $500

[Currently vacant. It could be you!](https://www.patreon.com/bePatron?patAmt=500.0&exp=1&u=4109762&rid=830876)

---

### $250

[Currently vacant. It could be you!](https://www.patreon.com/bePatron?patAmt=250.0&exp=1&u=4109762&rid=830877)

---

### $100

Juergen Schimmoeller

[Join here](https://www.patreon.com/bePatron?patAmt=100.0&exp=1&u=4109762&rid=830841)

---

### $50+

Kris Reddy<br>
Bart DJ

[Join here!](https://www.patreon.com/bePatron?exp=1&rid=830842&u=4109762&patAmt=50.0)

---

### $10+

Matthew Becker<br>
Greg Hatt<br>
Timo Ernst<br>
Dmitry Akinin<br>
Adrian Maleska<br>
Michael Kreinbihl<br>
Todd Crowe<br>
Thanakrit Tangtermsak<br>
Rick Chang<br>
Dave Billington

[Join here!](https://www.patreon.com/bePatron?exp=1&rid=830839&u=4109762&patAmt=10.0)

---

### $5+

Daniel Wüst<br>
Tirso Martínez Reyes<br>
Zafer Ayan<br>
Amir br<br>
Toby Allen - Ballymaloe Cookery School<br>
Dan Boschen<br>
Daniel Dingemanse<br>
Henry Blackman<br>
Ruslan Skorynin<br>
Sigfrido Rodríguez Santos

[Join here!](https://www.patreon.com/bePatron?exp=1&rid=845389&u=4109762&patAmt=5.0)
