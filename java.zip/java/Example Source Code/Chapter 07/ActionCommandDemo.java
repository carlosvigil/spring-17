/**
   This program creates an instance of the ActionCommandWindow
   class, which causes it to display its window.
*/

public class ActionCommandDemo
{
   public static void main(String[] args)
   {
      ActionCommandWindow acw = new ActionCommandWindow();
   }
}
