/**
   This program creates an instance of the EventObjectWindow
   class, which causes it to display its window.
*/

public class EventObjectDemo
{
   public static void main(String[] args)
   {
      EventObjectWindow eow = new EventObjectWindow();
   }
}
