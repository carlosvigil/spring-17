/**
   RetailItem interface
*/

public interface RetailItem
{
   public double getRetailPrice();
}
