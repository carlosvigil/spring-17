/**
   This class creates a program that calculates company payroll.
*/

public class Comment3
{
   /**
      The main method is the program's starting point.
   */
   
   public static void main(String[] args)        
   {
      double payRate;       // Holds the hourly pay rate
      double hours;         // Hours holds the hours worked
      int employeeNumber;   // Holds the employee number

      // The Remainder of This Program is Omitted.
   }
}

