/*
	Carlos Vigil
	Dr. C. Horvath
	Java @ GCC
	May 5th, 2017
	Chapter 8 - #9 Geometry Calculator
*/
