/** Carlos Vigil
 * Dr. Horvath
 * GCC Java
 * January 25, 2017
 *
 * Hello World example to confirm IDE installation. */

public class Hello
{
    public static void main(String[] args)
    {
        String words = "Hello, All.";
        System.out.println(words);
    }
}
