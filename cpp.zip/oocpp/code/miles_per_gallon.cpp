//
//  MilesPerGallon.hpp
//  code
//
//  Created by Carlos Vigil on 2/8/17.
//  Copyright © 2017 Carlos Vigil. All rights reserved.
//
/*
 Carlos Vigil
 Dr. Laurasi
 OOC++
 Feb. 1 2017
 Chapter 2 Code Assignment
 */

// 10. Miles Per Gallon
// calculate fixed MPG
#include <iostream>
using namespace std;

int main()
{
    int gas = 15, miles = 375;

    cout << "This vehicle gives " << miles / gas;
    cout << "MPG." << endl;

    return 0;
}
